<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class utilisateur extends Model
{
   

}
