<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class photos_produit extends Model
{
    //
}
