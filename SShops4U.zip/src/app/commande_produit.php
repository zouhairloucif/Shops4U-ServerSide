<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class commande_produit extends Model
{
    //
}
