<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class livraison extends Model
{
    //
}
