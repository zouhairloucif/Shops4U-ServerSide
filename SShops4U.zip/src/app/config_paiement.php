<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class config_paiement extends Model
{
    //
}
