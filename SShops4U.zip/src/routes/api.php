<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*===========================  Api Auth  ===========================*/

Route::group([
	'prefix' => 'auth'
], function ($router) {
	Route::post('login', 'AuthController@login');
	Route::post('logout', 'AuthController@logout');
	Route::post('refresh', 'AuthController@refresh');
	Route::post('me', 'AuthController@me');
	Route::post('userOrFail', 'AuthController@userOrFail');
	Route::post('isValid', 'AuthController@isValid');

});

/*===========================  Api user  ===========================*/

Route::group([
	'prefix' => 'user'
], function ($router) {
	Route::get('show', 'BackOffice\UserController@showUser');
	Route::post('signup', 'BackOffice\UserController@signup');
	Route::post('update', 'BackOffice\UserController@UpdateUser');
});

/*===========================  Api Catalogue  ===========================*/

Route::group([
	'prefix' => 'category'
], function ($router) {
	Route::get('all', 'BackOffice\CatalogueController@AllCategory');
	Route::get('show/{id}', 'BackOffice\CatalogueController@showCategory');
	Route::post('store', 'BackOffice\CatalogueController@StoreCategory');
	Route::put('update/{id}', 'BackOffice\CatalogueController@UpdateCategory');
	Route::delete('destroy/{id}', 'BackOffice\CatalogueController@DestroyCategory');
});

/*===========================  Api Catalogue  ===========================*/

Route::group([
	'prefix' => 'reduction'
], function ($router) {
	Route::get('all', 'BackOffice\CatalogueController@AllReduction');
	Route::get('show/{id}', 'BackOffice\CatalogueController@showReduction');
	Route::post('store', 'BackOffice\CatalogueController@StoreReduction');
	Route::put('update/{id}', 'BackOffice\CatalogueController@UpdateReduction');
	Route::delete('destroy/{id}', 'BackOffice\CatalogueController@DestroyReduction');
});

/*===========================  Api Catalogue  ===========================*/

Route::group([
	'prefix' => 'fournisseur'
], function ($router) {
	Route::get('all', 'BackOffice\CatalogueController@AllFournisseur');
	Route::get('show/{id}', 'BackOffice\CatalogueController@showFournisseur');
	Route::post('store', 'BackOffice\CatalogueController@StoreFournisseur');
	Route::put('update/{id}', 'BackOffice\CatalogueController@UpdateFournisseur');
	Route::delete('destroy/{id}', 'BackOffice\CatalogueController@DestroyFournisseur');
});

/*===========================  Api Marque  ===========================*/

Route::group([
	'prefix' => 'marque'
], function ($router) {
	Route::get('all', 'BackOffice\CatalogueController@AllMarque');
	Route::get('show/{id}', 'BackOffice\CatalogueController@showMarque');
	Route::post('store', 'BackOffice\CatalogueController@StoreMarque');
	Route::put('update/{id}', 'BackOffice\CatalogueController@UpdateMarque');
	Route::delete('destroy/{id}', 'BackOffice\CatalogueController@DestroyMarque');
});

/*===========================  Api Boutique  ===========================*/

Route::group([
	'prefix' => 'boutique'
], function ($router) {
	Route::post('store', 'BackOffice\BoutiqueController@StoreBoutique');
	Route::get('show/{id}', 'BackOffice\BoutiqueController@showBoutique');
	Route::post('update/{id}', 'BackOffice\BoutiqueController@UpdateBoutique');
	Route::post('maintenance', 'BackOffice\BoutiqueController@maintenance');
});

/*===========================  Api Paiement  ===========================*/

Route::group([
	'prefix' => 'paiement'
], function ($router) {
	Route::get('mode-paiements', 'BackOffice\PaiementController@modePaiements');
});